@file:OptIn(DexKitExperimentalApi::class)

package io.github.a092devs.nexfusion

import android.app.Application
import io.github.a092devs.nexfusion.compat.XC_MethodHook
import io.github.a092devs.nexfusion.compat.XposedBridge
import io.github.a092devs.nexfusion.compat.XposedHelpers
import io.github.libxposed.api.XposedInterface
import io.github.libxposed.api.XposedModuleInterface
import io.github.a092devs.nexfusion.morphe.Fingerprint
import org.luckypray.dexkit.DexKitBridge
import org.luckypray.dexkit.DexKitCacheBridge
import org.luckypray.dexkit.annotations.DexKitExperimentalApi
import org.luckypray.dexkit.result.ClassData
import org.luckypray.dexkit.result.FieldData
import org.luckypray.dexkit.result.MethodData
import org.luckypray.dexkit.wrap.DexClass
import org.luckypray.dexkit.wrap.DexField
import org.luckypray.dexkit.wrap.DexMethod
import java.lang.reflect.Constructor
import java.lang.reflect.Member
import java.lang.reflect.Method
import kotlin.reflect.KProperty0

typealias FindFunc = DexKitBridge.() -> Any
typealias FindClassFunc = DexKitBridge.() -> ClassData
typealias FindClassListFunc = DexKitBridge.() -> List<ClassData>
typealias FindMethodFunc = DexKitBridge.() -> MethodData
typealias FindMethodListFunc = DexKitBridge.() -> List<MethodData>
typealias FindFieldFunc = DexKitBridge.() -> FieldData
typealias FindFieldListFunc = DexKitBridge.() -> List<FieldData>

fun patch(
    name: String = "",
    description: String = "",
    use: Boolean = true,
    func: PatchExecutor.() -> Unit
) =
    Patch(name, description, use, func)

open class Patch(
    open val name: String,
    open val description: String,
    open val use: Boolean,
    open val run: PatchExecutor.() -> Unit
)

abstract class IHook(val xposed: XposedInterface) : XposedInterface by xposed {
    abstract val classLoader: ClassLoader

    fun DexMethod.hookMethod(callback: XC_MethodHook) {
        toMember().hookMethod(callback)
    }

    fun DexMethod.hookMethod(block: HookDsl<IHookCallback>.() -> Unit) {
        toMember().hookMethod(block)
    }

    fun DexClass.toClass() = getInstance(classLoader)
    fun DexMethod.toMethod(): Method {
        var clz = classLoader.loadClass(className)
        do {
            return XposedHelpers.findMethodExactIfExists(clz, name, *paramTypeNames.toTypedArray())
                ?: continue
        } while (clz.superclass.also { clz = it } != null)
        throw NoSuchMethodException("Method $this not found")
    }

    fun DexMethod.toConstructor(): Constructor<*> {
        var clz = classLoader.loadClass(className)
        do {
            return XposedHelpers.findConstructorExactIfExists(clz, *paramTypeNames.toTypedArray())
                ?: continue
        } while (clz.superclass.also { clz = it } != null)
        throw NoSuchMethodException("Method $this not found")
    }

    fun DexMethod.toMember(): Member {
        return when {
            isMethod -> toMethod()
            isConstructor -> toConstructor()
            else -> throw NotImplementedError()
        }
    }

    fun DexField.toField() = getFieldInstance(classLoader)

    override fun getApiVersion(): Int = xposed.apiVersion
}

class DependedHookFailedException(
    subHookName: String, exception: Throwable
) : Exception("Depended hook $subHookName failed.", exception)

/**
 * Raised when a finder finds no anchor or the anchor's lookup fails. Thrown instead of letting a
 * null reach DexKit, whose cache layer does not accept one (it fails with a bare
 * NullPointerException that names neither the fingerprint nor the app).
 */
class FingerprintNotFoundException(key: String, cause: Throwable? = null) :
    Exception("Fingerprint $key not found", cause)

/**
 * Applies the patches of one [PatchBundle] to the hooked app.
 *
 * Patches run as extension functions of this class, so everything here is available inside `patch { }`.
 */
open class PatchExecutor(
    val appContext: Application,
    val lpparam: XposedModuleInterface.PackageReadyParam,
    xposed: XposedInterface,
    /** The bundle the executed patches come from. */
    val bundle: BundleInfo,
    val dexkit: DexKitCacheBridge.RecyclableBridge,
    val sessionAppliedPatches: MutableSet<String>? = null,
) : IHook(xposed) {
    override val classLoader = lpparam.classLoader

    private val patchPreferences = runCatching { xposed.getRemotePreferences(lpparam.packageName) }.getOrNull()
    private val localPreferences by lazy {
        runCatching {
            appContext.getSharedPreferences("nexfusion_patch_prefs_${bundle.id}", Application.MODE_PRIVATE)
        }.getOrNull()
    }

    private val appliedPatches = mutableSetOf<Patch>()
    internal val failedPatches = mutableListOf<Patch>()

    internal fun executePatches(patches: Array<Patch>) {
        patches.forEach { hook ->
            if (appliedPatches.contains(hook)) return@forEach
            val prefKey = patchPreferenceKey(bundle.id, hook.name)
            val isEnabled = runCatching {
                val localTime = localPreferences?.getLong("${prefKey}_timestamp", 0L) ?: 0L
                val remoteTime = runCatching { patchPreferences?.getLong("${prefKey}_timestamp", 0L) ?: 0L }.getOrDefault(0L)
                if (localTime > 0L && localTime >= remoteTime) {
                    localPreferences?.getBoolean(prefKey, hook.use) ?: hook.use
                } else if (patchPreferences != null && patchPreferences.contains(prefKey)) {
                    val remoteVal = patchPreferences.getBoolean(prefKey, hook.use)
                    localPreferences?.edit()?.putBoolean(prefKey, remoteVal)?.apply()
                    remoteVal
                } else {
                    localPreferences?.getBoolean(prefKey, hook.use) ?: hook.use
                }
            }.getOrNull() ?: localPreferences?.getBoolean(prefKey, hook.use) ?: hook.use

            if (!isEnabled) {
                PatcherLog.state { "${bundle.id}: patch '${hook.name}' is DISABLED by user preference" }
                return@forEach
            }

            // Multi-source conflict prevention: skip duplicates already applied in this session
            if (hook.name.isNotEmpty() && !hook.name.startsWith("<")) {
                if (sessionAppliedPatches != null && sessionAppliedPatches.contains(hook.name)) {
                    PatcherLog.info { "Duplicate patch '${hook.name}' from bundle '${bundle.name}' skipped (already applied by prior bundle)" }
                    return@forEach
                }
            }

            runCatching { hook.run(this) }.onFailure { err ->
                XposedBridge.log("${bundle.id}: patch '${hook.name}' failed: ${err.message ?: err.javaClass.simpleName}")
                XposedBridge.log(err)
                PatcherLog.error(err) {
                    "${bundle.id}: patch '${hook.name}' failed: ${err.message ?: err.javaClass.simpleName}"
                }
                failedPatches.add(hook)
            }.onSuccess {
                appliedPatches.add(hook)
                if (hook.name.isNotEmpty() && !hook.name.startsWith("<")) {
                    sessionAppliedPatches?.add(hook.name)
                }
                PatcherLog.state { "${bundle.id}: applied patch '${hook.name}'" }
            }
        }
    }

    internal fun closeDexKit() = dexkit.close()

    fun dependsOn(vararg patches: Patch) {
        patches.forEach { hook ->
            if (appliedPatches.contains(hook)) return@forEach
            runCatching { (hook.run(this)) }.onFailure { err ->
                throw DependedHookFailedException(hook.name, err)
            }.onSuccess {
                appliedPatches.add(hook)
            }
        }
    }

    val KProperty0<FindMethodFunc>.dexMethod
        get() = getDexMethod(this.name, this.get())

    val KProperty0<FindMethodFunc>.method
        get() = dexMethod.toMethod()

    val KProperty0<FindMethodFunc>.constructor
        get() = dexMethod.toConstructor()

    val KProperty0<FindMethodFunc>.member
        get() = dexMethod.toMember()

    val KProperty0<FindMethodFunc>.memberOrNull
        get() = runCatching { this.member }.getOrNull()

    fun KProperty0<FindMethodFunc>.hookMethod(block: HookDsl<IHookCallback>.() -> Unit) {
        dexMethod.hookMethod(block)
    }

    fun KProperty0<FindMethodFunc>.hookMethod(callback: XC_MethodHook) {
        dexMethod.hookMethod(callback)
    }

    val KProperty0<FindMethodListFunc>.dexMethodList
        get() = getDexMethods(this.name, this.get())

    val KProperty0<FindFieldListFunc>.dexFieldList
        get() = getDexFields(this.name, this.get())

    val KProperty0<FindFieldFunc>.dexField
        get() = getDexField(this.name, this.get())

    val KProperty0<FindFieldFunc>.field
        get() = dexField.toField()

    val KProperty0<FindFieldFunc>.declaredClass
        get() = classLoader.loadClass(dexField.declaredClassName)

    val KProperty0<FindFieldFunc>.type
        get() = classLoader.loadClass(dexField.className)

    val KProperty0<FindClassFunc>.dexClass
        get() = getDexClass(this.name, this.get())

    val KProperty0<FindClassFunc>.clazz
        get() = dexClass.toClass()

    val KProperty0<FindClassListFunc>.dexClassList
        get() = getDexClasses(this.name, this.get())

    // Fingerprint object extensions

    private val Fingerprint.cacheKey
        get() = this::class.simpleName ?: error("Anonymous Fingerprint has no cache key")

    fun Fingerprint.hookMethod(block: HookDsl<IHookCallback>.() -> Unit) {
        getDexMethod(cacheKey) { this@hookMethod.run() }.hookMethod(block)
    }

    fun Fingerprint.hookMethod(callback: XC_MethodHook) {
        getDexMethod(cacheKey) { this@hookMethod.run() }.hookMethod(callback)
    }

    val Fingerprint.dexMethod get() = getDexMethod(cacheKey) { this@dexMethod.run() }

    val Fingerprint.member get() = dexMethod.toMember()

    val Fingerprint.memberOrNull get() = runCatching { this.member }.getOrNull()

    val Fingerprint.method get() = dexMethod.toMethod()

    val Fingerprint.declaredClass get() = classLoader.loadClass(dexMethod.declaredClassName)

    val Fingerprint.constructor get() = dexMethod.toConstructor()

    private inline fun <reified T : Any> wrapFind(
        key: String,
        crossinline funcFunc: DexKitBridge.() -> T,
        crossinline serializer: (T) -> String
    ): DexKitBridge.() -> T {
        return {
            val result = try {
                funcFunc()
            } catch (e: Exception) {
                PatcherLog.info(e) { "Fingerprint $key Not Found" }
                throw FingerprintNotFoundException(key, e)
            }
            PatcherLog.info { "$key Matches: ${serializer(result)}" }
            result
        }
    }

    private inline fun <reified T : Any> wrapFindList(
        key: String,
        crossinline funcFunc: DexKitBridge.() -> List<T>,
        crossinline serializer: (T) -> String
    ): DexKitBridge.() -> List<T> {
        return {
            try {
                funcFunc().also {
                    PatcherLog.info { "$key Matches: ${it.joinToString { serializer(it) }}" }
                }
            } catch (e: Exception) {
                PatcherLog.info(e) { "Fingerprint $key Not Found" }
                emptyList()
            }
        }
    }

    private inline fun getDexClass(
        key: String, crossinline findFunc: DexKitBridge.() -> ClassData
    ): DexClass = dexkit.getClassDirectOrNull(key, wrapFind(key, findFunc) { it.descriptor })!!

    private inline fun getDexClasses(
        key: String, crossinline findFunc: DexKitBridge.() -> List<ClassData>
    ): List<DexClass> = dexkit.getClassesDirectOrEmpty(
        key, wrapFindList(key, findFunc) { it.descriptor })

    private inline fun getDexMethod(
        key: String, crossinline findFunc: DexKitBridge.() -> MethodData
    ): DexMethod = dexkit.getMethodDirectOrNull(key, wrapFind(key, findFunc) { it.descriptor })!!

    private inline fun getDexField(
        key: String, crossinline findFunc: DexKitBridge.() -> FieldData
    ): DexField = dexkit.getFieldDirectOrNull(key, wrapFind(key, findFunc) { it.descriptor })!!

    private inline fun getDexMethods(
        key: String, crossinline findFunc: DexKitBridge.() -> List<MethodData>
    ): List<DexMethod> = dexkit.getMethodsDirectOrEmpty(
        key, wrapFindList(key, findFunc) { it.descriptor })

    private inline fun getDexFields(
        key: String, crossinline findFunc: DexKitBridge.() -> List<FieldData>
    ): List<DexField> = dexkit.getFieldsDirectOrEmpty(
        key, wrapFindList(key, findFunc) { it.descriptor })
}
