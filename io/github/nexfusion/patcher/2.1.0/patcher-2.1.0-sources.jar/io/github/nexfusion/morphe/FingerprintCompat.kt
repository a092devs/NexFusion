package io.github.nexfusion.morphe

import io.github.nexfusion.FindClassFunc
import io.github.nexfusion.FindFieldFunc
import io.github.nexfusion.FindFieldListFunc
import io.github.nexfusion.FindMethodFunc
import io.github.nexfusion.FindMethodListFunc
import org.luckypray.dexkit.DexAccessFlags
import org.luckypray.dexkit.DexKitBridge
import org.luckypray.dexkit.query.matchers.ClassMatcher
import org.luckypray.dexkit.query.matchers.MethodMatcher
import org.luckypray.dexkit.query.matchers.base.OpCodesMatcher
import org.luckypray.dexkit.result.InstructionData
import org.luckypray.dexkit.result.MethodData
import org.luckypray.dexkit.util.DexSignUtil.getTypeName

fun getTypeNameCompat(it: String): String? {
    return when {
        it == "this" -> null
        it.trimStart('[').startsWith('L') && !it.endsWith(';') -> null
        else -> getTypeName(it)
    }
}

enum class AccessFlags(val modifier: Int) {
    PUBLIC(DexAccessFlags.PUBLIC),
    PRIVATE(DexAccessFlags.PRIVATE),
    PROTECTED(DexAccessFlags.PROTECTED),
    STATIC(DexAccessFlags.STATIC),
    FINAL(DexAccessFlags.FINAL),
    SYNCHRONIZED(DexAccessFlags.SYNCHRONIZED),
    SUPER(DexAccessFlags.SUPER),
    VOLATILE(DexAccessFlags.VOLATILE),
    BRIDGE(DexAccessFlags.BRIDGE),
    TRANSIENT(DexAccessFlags.TRANSIENT),
    VARARGS(DexAccessFlags.VARARGS),
    NATIVE(DexAccessFlags.NATIVE),
    INTERFACE(DexAccessFlags.INTERFACE),
    ABSTRACT(DexAccessFlags.ABSTRACT),
    STRICTFP(DexAccessFlags.STRICT),
    SYNTHETIC(DexAccessFlags.SYNTHETIC),
    ANNOTATION(DexAccessFlags.ANNOTATION),
    ENUM(DexAccessFlags.ENUM),
    CONSTRUCTOR(DexAccessFlags.CONSTRUCTOR),
    DECLARED_SYNCHRONIZED(DexAccessFlags.DECLARED_SYNCHRONIZED),
}

fun MethodMatcher.strings(vararg strings: String) = this.usingStrings(strings.toList())

fun MethodMatcher.opcodes(vararg opcodes: Opcode): OpCodesMatcher {
    return OpCodesMatcher(opcodes.map { it.opCode }).also {
        this.opCodes(it)
    }
}

fun MethodMatcher.opcodes(opcodes: Collection<Opcode>): OpCodesMatcher {
    return OpCodesMatcher(opcodes.map { it.opCode }).also {
        this.opCodes(it)
    }
}

fun MethodMatcher.accessFlags(vararg accessFlags: AccessFlags) {
    val modifiers = accessFlags.map { it.modifier }.reduce { acc, next -> acc or next }
    if (modifiers != 0) this.accessFlags(modifiers)
    if (accessFlags.contains(AccessFlags.CONSTRUCTOR)) {
        if (accessFlags.contains(AccessFlags.STATIC)) this.name = "<clinit>"
        else this.name = "<init>"
    }
}

fun MethodMatcher.parameters(vararg parameters: String) {
    this.paramTypes(parameters.map(::getTypeNameCompat))
}

fun MethodMatcher.parameters(parameters: Collection<String>) {
    this.paramTypes(parameters.map(::getTypeNameCompat))
}

fun MethodMatcher.returns(returnType: String) {
    getTypeNameCompat(returnType)?.let { this.returnType = it }
}

fun MethodMatcher.literal(literalSupplier: () -> Number) {
    this.usingNumbers(literalSupplier())
}


private fun findLongestOpcodeSequence(filters: List<InstructionFilter>): List<InstructionFilter> {
    if (filters.isEmpty()) return emptyList()

    val chunks = mutableListOf<MutableList<InstructionFilter>>()

    for (filter in filters) {
        if (filter.location is InstructionLocation.MatchAfterImmediately) {
            if (chunks.isNotEmpty()) {
                chunks.last().add(filter)
            } else {
                chunks.add(mutableListOf(filter))
            }
        } else {
            chunks.add(mutableListOf(filter))
        }
    }

    return chunks.filter { it.all { it is OpcodeFilter } }.maxByOrNull { it.size }
        ?: emptyList()
}

class FingerprintDsl(init: FingerprintDsl.() -> Unit) {
    private var name: String? = null
    private var definingClass: String? = null
    private var accessFlags: List<AccessFlags>? = null
    private var returnType: String? = null
    private var parameters: List<String>? = null
    private var strings: Array<out String>? = null
    private var classFinder: FindClassFunc? = null
    private var classMatcherBlock: (ClassMatcher.() -> Unit)? = null
    private val methodMatcherBlocks = mutableListOf<MethodMatcher.() -> Unit>()

    init {
        init(this)
    }

    fun name(name: String) {
        this.name = name
    }

    fun definingClass(descriptor: String) {
        this.definingClass = descriptor
    }

    fun strings(vararg strings: String) {
        this.strings = strings
    }

    fun opcodes(vararg opcodes: Opcode): OpCodesMatcher {
        val matcher = OpCodesMatcher(opcodes.map { it.opCode })
        methodMatcherBlocks += { opCodes(matcher) }
        return matcher
    }

    fun accessFlags(vararg accessFlags: AccessFlags) {
        this.accessFlags = accessFlags.toList()
    }

    fun parameters(vararg parameters: String) {
        this.parameters = parameters.toList()
    }

    fun returns(returnType: String) {
        this.returnType = returnType
    }

    fun literal(literalSupplier: () -> Number) {
        methodMatcherBlocks += { literal(literalSupplier) }
    }

    fun classFingerprint(findMethodFunc: FindMethodFunc) {
        classFinder = { findMethodFunc().declaredClass!! }
    }

    /**
     * Direct access to DexKit MethodMatcher for custom queries.
     */
    fun methodMatcher(block: MethodMatcher.() -> Unit) {
        methodMatcherBlocks += block
    }

    /**
     * DexKit ClassMatcher for chain-matching (find class first, then find method within).
     */
    fun classMatcher(block: ClassMatcher.() -> Unit) {
        classMatcherBlock = block
    }

    fun build(): Fingerprint {
        methodMatcherBlocks += { strings?.let { strings(*it) } }

        val fp = Fingerprint(
            definingClass = definingClass,
            name = name,
            accessFlags = accessFlags,
            returnType = returnType,
            parameters = parameters,
        )

        // Apply classFinder or classMatcher
        if (classFinder != null) {
            fp.legacyClassFinder = classFinder
        }
        if (classMatcherBlock != null) {
            fp.classMatcherBlock = classMatcherBlock
        }

        // Apply extra methodMatcher blocks
        if (methodMatcherBlocks.isNotEmpty()) {
            fp.extraMethodMatcherBlocks = methodMatcherBlocks.toList()
        }

        return fp
    }
}

/**
 * DexKit Query is not equivalent to instruction matching. <br>
 * This annotation forces the query results to be filtered again using instruction matching.
 * @see Fingerprint.run
 * */
annotation class StrictQuery

open class Fingerprint(
    val classFingerprint: Fingerprint? = null,
    definingClass: String? = null,
    name: String? = null,
    accessFlags: List<AccessFlags>? = null,
    returnType: String? = null,
    parameters: List<String>? = null,
    val filters: List<InstructionFilter>? = null,
    strings: List<String>? = null,
    custom: (MethodMatcher.() -> Unit)? = null
) {
    internal var legacyClassFinder: FindClassFunc? = null
    internal var classMatcherBlock: (ClassMatcher.() -> Unit)? = null
    internal var extraMethodMatcherBlocks: List<MethodMatcher.() -> Unit>? = null

    init {
        if (custom != null)
            extraMethodMatcherBlocks = listOf(custom)
    }

    /**
     * Set class matcher for chain matching (find class first, then method within).
     * Can be called from object init blocks.
     */
    protected fun classMatcher(block: ClassMatcher.() -> Unit) {
        classMatcherBlock = block
    }

    private val methodMatcherBuilder = fun MethodMatcher.(): Unit {
        definingClass?.let(::getTypeNameCompat)?.let { declaredClass(it) }
        if (name != null) name(name)
        if (accessFlags != null) accessFlags(*accessFlags.toTypedArray())
        if (returnType != null) returns(returnType)
        if (parameters != null) parameters(*parameters.toTypedArray())
        if (strings != null) for (str in strings) addEqString(str)
        filters?.forEach { filter ->
            filter.addQuery()
        }

        filters?.also {
            val opcodes = findLongestOpcodeSequence(it).map { filter ->
                when (filter) {
                    is OpcodeFilter -> filter.opcode.ordinal
                    else -> throw IllegalStateException()
                }
            }
            if (opcodes.any())
                opCodes(opcodes)
        }

        extraMethodMatcherBlocks?.forEach { block -> block() }
    }

    fun buildMethodMatcher(): MethodMatcher =
        MethodMatcher().apply(methodMatcherBuilder)

    /**
     * A fingerprint for a method. A fingerprint is a partial description of a method,
     * used to uniquely match a method by its characteristics.
     *
     * See the patcher documentation for more detailed explanations and example fingerprinting.
     *
     * @param classFingerprint Fingerprint that finds the class this fingerprint resolves against.
     * @param name Exact method name.
     * @param accessFlags The exact access flags using values of [AccessFlags].
     * @param returnType The return type. Type declaration follow the semantics described in [StringComparisonType].
     * @param parameters The parameters. Type declaration follow the semantics described in [StringComparisonType].
     * @param filters A list of filters to match, declared in the same order the instructions appear in the method.
     * @param strings A list of strings that appear anywhere in the method in any order. Compared using [String.contains].
     * @param custom A custom condition for this fingerprint.
     */
    constructor(
        classFingerprint: Fingerprint? = null,
        name: String? = null,
        accessFlags: List<AccessFlags>? = null,
        returnType: String? = null,
        parameters: List<String>? = null,
        filters: List<InstructionFilter>? = null,
        strings: List<String>? = null,
        custom: (MethodMatcher.() -> Unit)? = null,
    ) : this(
        classFingerprint, null, name, accessFlags, returnType, parameters, filters, strings, custom
    )

    /**
     * A fingerprint for a method. A fingerprint is a partial description of a method,
     * used to uniquely match a method by its characteristics.
     *
     * See the patcher documentation for more detailed explanations and example fingerprinting.
     *
     * @param name Exact method name.
     * @param accessFlags The exact access flags using values of [AccessFlags].
     * @param returnType The return type. Type declaration follow the semantics described in [StringComparisonType].
     * @param parameters The parameters. Type declaration follow the semantics described in [StringComparisonType].
     * @param filters A list of filters to match, declared in the same order the instructions appear in the method.
     * @param strings A list of strings that appear anywhere in the method in any order. Compared using [String.contains].
     * @param custom A custom condition for this fingerprint.
     */
    constructor(
        name: String? = null,
        accessFlags: List<AccessFlags>? = null,
        returnType: String? = null,
        parameters: List<String>? = null,
        filters: List<InstructionFilter>? = null,
        strings: List<String>? = null,
        custom: (MethodMatcher.() -> Unit)? = null,
    ) : this(
        null, null, name, accessFlags, returnType, parameters, filters, strings, custom
    )

    /**
     * A fingerprint for a method. A fingerprint is a partial description of a method,
     * used to uniquely match a method by its characteristics.
     *
     * See the patcher documentation for more detailed explanations and example fingerprinting.
     *
     * @param definingClass Defining class. Type declaration follow the semantics described in [StringComparisonType].
     * @param name Exact method name.
     * @param accessFlags The exact access flags using values of [AccessFlags].
     * @param returnType The return type. Type declaration follow the semantics described in [StringComparisonType].
     * @param parameters The parameters. Type declaration follow the semantics described in [StringComparisonType].
     * @param filters A list of filters to match, declared in the same order the instructions appear in the method.
     * @param strings A list of strings that appear anywhere in the method in any order. Compared using [String.contains].
     * @param custom A custom condition for this fingerprint.
     */
    constructor(
// Required to disambiguate if defining class or class fingerprint is not specified.
        definingClass: String? = null,
        name: String? = null,
        accessFlags: List<AccessFlags>? = null,
        returnType: String? = null,
        parameters: List<String>? = null,
        filters: List<InstructionFilter>? = null,
        strings: List<String>? = null,
        custom: (MethodMatcher.() -> Unit)? = null,
    ) : this(
        null, definingClass, name, accessFlags, returnType, parameters, filters, strings, custom
    )

    context(dexkit: DexKitBridge)
    operator fun invoke(): MethodData {
        return run()
    }

    /**
     * Finds a unique method result using DexKit query.
     *
     * When strict mode is enabled and multiple candidates are found,
     * applies instruction matching to narrow down the results.
     */
    context(dexkit: DexKitBridge)
    fun run(): MethodData {
        var results: List<MethodData> = queryAll()

        if (results.size > 1 && isStrict) {
            results = results.filter { matchOrNull(it) != null }
        }

        if (results.size != 1) {
            val name = this::class.simpleName ?: "Anonymous Fingerprint"
            val list = results.joinToString("\n  ") { it.descriptor }
            System.err.println("$name matched ${results.size} methods:\n  $list")
        }
        return results.single()
    }

    private val isStrict = this::class.java.annotations.filterIsInstance<StrictQuery>().isNotEmpty()

    context(dexkit: DexKitBridge)
    private fun queryAll(): List<MethodData> {
        val methodMatcher = buildMethodMatcher()
        val results: List<MethodData> = if (classMatcherBlock != null) {
            dexkit.findClass {
                matcher(ClassMatcher().apply(classMatcherBlock!!))
            }.findMethod {
                matcher(methodMatcher)
            }
        } else if (classFingerprint != null) {
            val classes = classFingerprint.queryAll().map { it.declaredClass!! }

            dexkit.findMethod {
                searchInClass(classes)
                matcher(methodMatcher)
            }
        } else if (legacyClassFinder != null) {
            legacyClassFinder!!.invoke(dexkit).findMethod {
                matcher(methodMatcher)
            }
        } else {
            dexkit.findMethod {
                matcher(methodMatcher)
            }
        }

        if (results.size > 10) {
            throw IllegalStateException("Bad query, too much results")
        }

        return results
    }

    context(dexkit: DexKitBridge)
    fun match() = matchOrNull(run()) ?: throw Exception("getInstructionMatches failed")

    context(dexkit: DexKitBridge)
    fun matchOrNull() = matchOrNull(run())

    fun matchOrNull(
        method: MethodData
    ): Match? {
        val filtersLocal = filters
        val instructionMatches = if (filtersLocal == null) {
            null
        } else {
            val instructions = method.instructions.toList() ?: return null

            fun matchFilters(): List<Match.InstructionMatch>? {
                val lastMethodIndex = instructions.lastIndex
                var instructionMatches: MutableList<Match.InstructionMatch>? = null

                var firstInstructionIndex = 0
                var lastMatchIndex = -1

                firstFilterLoop@ while (true) {
                    // Matched index of the first filter.
                    var firstFilterIndex = -1
                    var subIndex = firstInstructionIndex

                    for (filterIndex in filtersLocal.indices) {
                        val filter = filtersLocal[filterIndex]
                        val location = filter.location
                        var instructionsMatched = false

                        while (subIndex <= lastMethodIndex &&
                            location.indexIsValidForMatching(
                                lastMatchIndex, subIndex
                            )
                        ) {
                            val instruction = instructions[subIndex]
                            if (filter.matches(method, instruction)) {
                                lastMatchIndex = subIndex

                                if (filterIndex == 0) {
                                    firstFilterIndex = subIndex
                                }
                                if (instructionMatches == null) {
                                    instructionMatches = ArrayList(filtersLocal.size)
                                }
                                instructionMatches += Match.InstructionMatch(
                                    filter,
                                    subIndex,
                                    instruction
                                )
                                instructionsMatched = true
                                subIndex++
                                break
                            }
                            subIndex++
                        }

                        if (!instructionsMatched) {
                            if (filterIndex == 0) {
                                return null // First filter has no more matches to start from.
                            }

                            // Try again with the first filter, starting from
                            // the next possible first filter index.
                            firstInstructionIndex = firstFilterIndex + 1
                            lastMatchIndex = -1
                            instructionMatches?.clear()
                            continue@firstFilterLoop
                        }
                    }

                    // All instruction filters matches.
                    return instructionMatches
                }
            }

            matchFilters() ?: return null
        }

        return Match(
            method,
            instructionMatches
        )
    }

    context(_: DexKitBridge)
    val instructionMatches
        get() = match().instructionMatches

    /**
     * Match all methods in the target app.
     *
     * @return All methods that match.
     * @throws Exception If the fingerprint failed to match any methods.
     */
    context(patchContext: DexKitBridge)
    fun matchAll() = matchAllOrNull() ?: throw Exception()

    context(_: DexKitBridge)
    fun matchAllOrNull(): List<Match>? {
        return queryAll().mapNotNull { matchOrNull(it) }
            .distinctBy(Match::method)
            .ifEmpty { null }
    }
}

class Match constructor(
    val method: MethodData,
    private val _instructionMatches: List<InstructionMatch>?,
) {

    /**
     * Matches corresponding to the [InstructionFilter] declared in the [Fingerprint].
     */
    val instructionMatches
        get() = _instructionMatches
            ?: throw Exception("Fingerprint declared no instruction filters")
    val instructionMatchesOrNull = _instructionMatches

    /**
     * A match for an [InstructionFilter].
     * @param filter The filter that matched
     * @param index The instruction index it matched with.
     * @param instruction The instruction that matched.
     */
    class InstructionMatch internal constructor(
        val filter: InstructionFilter,
        val index: Int,
        val instruction: InstructionData
    ) {
        /**
         * Helper method to simplify casting the instruction to it's known and expected type.
         */
        @Suppress("UNCHECKED_CAST")
        fun <T> getInstruction(): T = instruction as T

        override fun toString(): String {
            return "InstructionMatch{filter='${filter.javaClass.simpleName}, opcode='${instruction.opcode}, 'index=$index}"
        }
    }

    override fun toString(): String {
        return "Match(originalMethod=$method, " +
                "instructionMatches=$_instructionMatches)"
    }
}

fun DexKitBridge.fingerprint(block: FingerprintDsl.() -> Unit): MethodData {
    return FingerprintDsl(block).build().run()
}

fun fingerprint(block: FingerprintDsl.() -> Unit): FindMethodFunc {
    return { FingerprintDsl(block).build().run() }
}

fun findMethodDirect(block: FindMethodFunc) = block
fun findMethodListDirect(block: FindMethodListFunc) = block
fun findClassDirect(block: FindClassFunc) = block
fun findFieldDirect(block: FindFieldFunc) = block
fun findFieldListDirect(block: FindFieldListFunc) = block
